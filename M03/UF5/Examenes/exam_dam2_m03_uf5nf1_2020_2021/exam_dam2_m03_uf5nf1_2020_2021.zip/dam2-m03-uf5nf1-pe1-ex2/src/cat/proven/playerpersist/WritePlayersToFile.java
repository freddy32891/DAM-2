package cat.proven.playerpersist;

/**
 * Program to test write method from interface PlayersPersist
 * @author 
 */
public class WritePlayersToFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO create test data
        // Retrieve file name
        // Write players to file
        System.out.println("TODO: write player list to a file ");
    }
    
}
