package cat.proven.playerpersist;

/**
 * Program to tesst read method from interface PlayersPersist
 * @author 
 */
public class ReadPlayersFromFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO 
        // Retrieve file name
        // Read data from file
        // Show players read
        System.out.println("TODO: read player list from file ");
    }
    
}
