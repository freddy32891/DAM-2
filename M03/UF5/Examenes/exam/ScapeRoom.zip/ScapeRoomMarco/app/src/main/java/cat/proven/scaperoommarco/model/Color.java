package cat.proven.scaperoommarco.model;

public enum Color {
    _RED,
    _BLUE,
    _GREEN,
    _GREY
}
