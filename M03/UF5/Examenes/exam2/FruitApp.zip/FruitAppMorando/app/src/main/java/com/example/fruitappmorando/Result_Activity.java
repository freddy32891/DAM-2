package com.example.fruitappmorando;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Result_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
    }

}